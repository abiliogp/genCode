
public abstract class Sensor{

	/*
	 *Attribute of Return Method check
	 */
	public boolean full;

	/*
	 *Method
	 */
	public abstract boolean check();
}