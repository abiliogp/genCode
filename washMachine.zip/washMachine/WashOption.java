
public class WashOption{

	/*
	 *Attributes
	 */
	private int washSelection;

	/*
	 *Constructor
	 */
	public WashOption( int washSelection ){
		this.washSelection = washSelection;
	}


	/*
	 *Get
	 */
	public int getWashSelection(){
		return this.washSelection;
	}


	/*
	 *Set
	 */
	public void setWashSelection( int washSelection ){
		 this.washSelection = washSelection;
	}

}