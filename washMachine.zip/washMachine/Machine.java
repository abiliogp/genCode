
public interface Machine{

	/*
	 *Method
	 */
	void turnOn();
	void turnOff();
}