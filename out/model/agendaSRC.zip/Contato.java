
public class Contato{

	/** Constructor */
	public Contato(){
	}

	/** Methods */
	public void criaContato(){
	}

}